Projeto criado por Daniel Galvão.
Destina-se um sistema de Gerenciamento  de clinica para Psicólogos.
