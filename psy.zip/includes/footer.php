<footer>
        <p>&copy; 2024 Sistema de Gestão. Todos os direitos reservados.</p>
    </footer>
    <script src="../assets/js/scripts.js"></script>
</body>
</html>
